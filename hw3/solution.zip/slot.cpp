/*
 * Code to cache simulation
 * CSF Assignment 3 MS1
 * Theo DeGuzman
 * tdeguzm1@jhu.edu
 */

#include "slot.h"

slot::slot(unsigned new_tag, unsigned num_bytes){
    tag = new_tag;
    size = num_bytes;
    load_ts = 0;
    access_ts = 0;
    valid = 0;
    dirty = 0;

}