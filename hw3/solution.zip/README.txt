This assignment was done individually, with all requirements for MS1 complete.

MS2:
TODOS:
make cache_stats dynamic memory