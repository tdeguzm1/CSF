This assignment was done individually, with all requirements for MS2 complete.

No bugs were found, and gradescope autograders were passed. Valgrind also passed.
Some opportunites for optimization are present and will be implemeted for MS3.
Also Fifo should work, even though LRU was the requirement for this milestone. 